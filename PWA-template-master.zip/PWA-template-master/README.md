# PWA-template

Template to get you started with your PWA in pure VanillaJS
